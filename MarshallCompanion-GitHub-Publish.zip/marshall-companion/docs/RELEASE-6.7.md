# Marshall Companion v6.7

Windows 10/11 x64 便携版。解压后运行 MarshallCompanion.exe。

- 蓝牙设备选择、自检、重连测试及保活测试。
- 按需保活、夜间免打扰、托盘运行。
- 内置“开机自启动”开关。
- Marshall 风格界面、红灯光晕、等比例调整窗口。

需要 .NET Framework 4.8 和 WebView2 Runtime。重连及保活依赖设备与驱动，尚未进行全型号硬件验证。非官方项目。

Windows x64 portable build. Extract and run MarshallCompanion.exe. Requires .NET Framework 4.8 and WebView2 Runtime. Compatibility depends on the device and driver; this is not an official Marshall product.
