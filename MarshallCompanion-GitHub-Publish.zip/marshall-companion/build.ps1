param()
$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows x64 is required.' }
$version = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'VERSION') -Raw).Trim()
$output = Join-Path $PSScriptRoot 'dist\MarshallCompanion'
$source = Join-Path $PSScriptRoot 'src'
$vendor = Join-Path $PSScriptRoot 'vendor\webview2'
$framework = Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'Install .NET Framework 4.8 and build on Windows x64.' }
New-Item -ItemType Directory -Path $output -Force | Out-Null
Get-ChildItem -LiteralPath $source -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $output -Force }
Get-ChildItem -LiteralPath $vendor -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $output -Force }
$compilerArgs = @('/nologo', '/target:winexe', '/platform:x64', '/langversion:5', ('/out:' + (Join-Path $output 'MarshallCompanion.exe')))
foreach ($assembly in @('System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll','System.Web.Extensions.dll','System.Runtime.Serialization.dll','System.Net.Http.dll')) {
    $compilerArgs += '/reference:' + (Join-Path $framework $assembly)
}
foreach ($assembly in @('Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.WinForms.dll')) {
    $compilerArgs += '/reference:' + (Join-Path $vendor $assembly)
}
$compilerArgs += Join-Path $source 'MarshallCompanion.cs'
& $compiler @compilerArgs
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
$archive = Join-Path $PSScriptRoot ('dist\MarshallCompanion-v' + $version + '-Windows-x64.zip')
Compress-Archive -LiteralPath $output -DestinationPath $archive -Force
Write-Host ('Built: ' + $archive)
