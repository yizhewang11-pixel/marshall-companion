# Marshall Companion

Windows 蓝牙音箱助手 · Windows Bluetooth speaker helper

**当前版本：6.7 · Windows 10/11 x64**

独立开发的非官方工具，与 Marshall 无隶属、授权或背书关系。界面中的 Marshall 名称和标志用于识别兼容用途；相关品牌权利属于其权利人。

## 下载与使用

在本仓库的 **Releases** 页面下载 Windows ZIP，完整解压，双击 `MarshallCompanion.exe`。更新前请从系统托盘退出旧版。

1. 在 Windows 中配对音箱。
2. 打开下排中间的 **检测与设置**，刷新列表，选择目标设备并保存。
3. 需要时执行重连测试或保活测试（会发声）。
4. 可在同一页面开启 **开机自启动**，下次登录自动在托盘运行。

需要 .NET Framework 4.8 和 [Microsoft Edge WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/)。ZIP 包含 WebView2 接口库，不包含完整浏览器运行时。

## 功能

- 断线后按 1–60 分钟间隔向蓝牙音频驱动请求重连。
- 检测到连接后选择目标音频输出。
- 仅检测输出音量，不录制声音、不使用麦克风。
- 连续约 8 分钟无声后播放 2 秒轻音以尝试防止待机；声音可能被听见。
- 每日免打扰时段默认 00:00–08:00，暂停重连、输出切换和保活。
- 关闭窗口后在托盘运行；托盘菜单“退出”才完全停止。
- 支持选择已识别的蓝牙音频设备，不依赖 Marshall 型号或设备名称。
- 中英文界面、80% 默认尺寸、边缘等比例缩放。

## 兼容性与限制

这不是“所有 Marshall 型号和代数均经过验证”的承诺。可用性取决于 Windows 蓝牙驱动、音频端点和音箱固件。

- 设备必须已在 Windows 中配对并建立音频端点；部分驱动可能无法识别。
- 程序不能唤醒已断电的音箱，也不能在电脑睡眠/关机时运行。
- 请求已发送不等于连接成功。重连测试最多观察 20 秒；已连接时不主动断开测试。
- 保活测试成功只说明播放操作完成，是否有效防止待机需实际观察。
- 已进行编译与模拟界面消息测试；未进行跨型号、跨驱动硬件验证。

## 构建

在 Windows x64、安装 .NET Framework 4.8 的环境中使用 Windows PowerShell：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

输出位于 `dist/MarshallCompanion`，同时生成 ZIP。该构建脚本使用系统 C# 编译器及本仓库固定版本的 WebView2 SDK 接口库（1.0.2903.40）。构建脚本本身尚未在 Windows 上运行验证。

## 本地数据

设置保存到 `%LOCALAPPDATA%\MarshallCompanion\settings.json`；自启动副本位于同目录下的 `App`。内存中保留本次运行最近 80 条日志。请不要把个人设置或诊断中的设备 ID 上传到公开 Issue。

## English

An unofficial Windows x64 utility for Bluetooth speakers. It offers driver-based reconnect requests, output selection, silence-triggered keep-awake audio, quiet hours, tray operation and sign-in startup. It is not affiliated with or endorsed by Marshall.

Download the Windows ZIP from **Releases**, extract it, and launch `MarshallCompanion.exe`. Pair the speaker in Windows, then choose and save it under **Checks & setup**. Requires .NET Framework 4.8 and WebView2 Runtime.

No model-name allowlist is used. This does **not** establish compatibility with every model, generation or Bluetooth driver. Keep-awake audio may be audible. The app cannot power on a speaker or run while the PC is asleep. Hardware validation remains necessary.

## 第三方组件 / Third-party components

WebView2 SDK 1.0.2903.40: see `vendor/webview2/WebView2-LICENSE.txt` and `WebView2-NOTICE.txt`.

本次发布未另行授予项目代码的开源许可。公开源码不等于已经采用 MIT、Apache 等许可。第三方组件遵循各自许可。
No project-wide open-source license has been selected for this release. Third-party components retain their own licenses.
